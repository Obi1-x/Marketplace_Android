package com.example.obi1.a3ade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.Serializable;

public class StoreActivity extends AppCompatActivity {
    EditText mNameSet;
    EditText mDescripSet;
    StoreInfo storeinfo;
    ProductInfo productinfo;
    private EditText mPriceSet;
    public static int rowClickPos;
    FirebaseDatabase myFirebase;
    DatabaseReference mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_info);

        myFirebase = FirebaseUtil.myFirebase;
        mydatabase = FirebaseUtil.mydatabase; //"tradeData" DB reference

        mNameSet = (EditText) findViewById(R.id.Name_set_et);
        mDescripSet = (EditText)findViewById(R.id.Descrip_set_et);
        mPriceSet = (EditText)findViewById(R.id.Price_set_et);

       // Intent intent = getIntent(); //Receives intent used to start this activity from list activity
       // StoreInfo storeinf = (StoreInfo) intent.getSerializableExtra("rowPos");

        final int usesnavItemId = Dashboard.navItemId;
        if(usesnavItemId != 300) { //If Store Activity was opened to create a store.
            mPriceSet.setVisibility(View.GONE);
        }
       // storeinfo = storeinf;
        storeinfo = new StoreInfo();
        productinfo = new ProductInfo();

        Button createStore = findViewById(R.id.createStore_b);
        createStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(usesnavItemId == 300){ //Create Product. Products Array has been displayed

                    productinfo.setStoreName(Dashboard.firstStoreInfo.get(rowClickPos).storeName); //Sets the store name you are working in
                    productinfo.setProductName(mNameSet.getText().toString());
                    productinfo.setProductDescription(mDescripSet.getText().toString());
                    productinfo.setPrice(mPriceSet.getText().toString());
                    productinfo.setUserName(FirebaseUtil.userName); //Attaches the username of the seller to the product
                    //Dashboard.storeProducts.add(productinfo);
                    Dashboard.dashboardFeeds.add(productinfo); //All products are deposited to dashboardfees array with its store name as an identifier.
                    StoreActivity.StoreInfo store = Dashboard.firstStoreInfo.get(rowClickPos);
                    Intent intent = new Intent(StoreActivity.this, Dashboard.class); //Goes back to Dashboard activity
                    intent.putExtra("Selected navMenu", usesnavItemId);
                    intent.putExtra("Selected store", store);
                    startActivity(intent);

                } else{ //Create Store. Products array has not yet been displayed, at least once.

                    storeinfo.setStoreName(mNameSet.getText().toString());
                    storeinfo.setStoreDescription(mDescripSet.getText().toString());
                    Dashboard.firstStoreInfo.add(storeinfo);
                    //mydatabase.get
                    mydatabase.push().setValue(storeinfo);

                    Intent intent = new Intent(StoreActivity.this, Dashboard.class); //Goes back to Dashboard activity
                    intent.putExtra("Selected navMenu", R.id.stores);
                    startActivity(intent);

                }

            }
        });

    }

    public static class StoreInfo implements Serializable {
        private String storeName;
        private String storeDescription;
        //private String UserName;
        private int image; //Find a way to use only the id or uri later on

        public StoreInfo(){}

        public StoreInfo(String StoreName, String StoreDescription, int image){
            this.setImage(image);
            //this.UserName = userName;
            this.setStoreName(StoreName);
            this.setStoreDescription(StoreDescription);
        }

        private void setStoreDescription(String StoreDescription) {
            this.storeDescription = StoreDescription;
        }

        public String getStoreDescription() {
            return storeDescription;
        }

        private void setStoreName(String StoreName) {
            this.storeName = StoreName;
        }

        public String getStoreName() {
            return storeName;
        }

        public int getImage() {
            return image;
        }

        public void setImage(int image) {
            this.image = image;
        }

   /*     public String getUserName() {
            return UserName;
        }

        public void setUserName(String userName) {
            UserName = userName;
        }*/
    }

    public static class ProductInfo implements Serializable {
        private String storeName;
        private String productName;
        private String productDescription;
        private String productNo;
        private int productImage; //Find a way to use only the id or uri later on
        private String price;
        private String UserName;
        private String cartId;

        public ProductInfo(){}

        public ProductInfo(String StoreName, String ProductName, String ProductDescription,  String ProductNo, int ProductImage, String price, String UserName){
            this.setStoreName(StoreName);
            this.setProductName(ProductName);
            this.setProductDescription(ProductDescription);
            this.setProductNo(ProductNo);
            this.setProductImage(ProductImage);
            this.setPrice(price);
            this.setUserName(UserName);
        }

        private void setStoreName(String StoreName) {
            this.storeName = StoreName;
        }

        public String getStoreName() {
            return storeName;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public String getProductDescription() {
            return productDescription;
        }

        public void setProductDescription(String productDescription) {
            this.productDescription = productDescription;
        }

        public String getProductNo() {
            return productNo;
        }

        public void setProductNo(String productNo) {
            this.productNo = productNo;
        }

        public int getProductImage() {
            return productImage;
        }

        public void setProductImage(int productImage) {
            this.productImage = productImage;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getPrice() {
            return price;
        }

        public String getUserName() {
            return UserName;
        }

        public void setUserName(String userName) {
            UserName = userName;
        }

        public String getCartId() {
            return cartId;
        }

        public void setCartId(String cartId) {
            this.cartId = cartId;
        }
    }


    public static class CartListInfo implements Serializable {
        private String cartId;
        private int cartStatus;

        public CartListInfo(){}

        public CartListInfo(String cartId, int cartStatus){
            this.setCartId(cartId);
            this.setCartStatus(cartStatus);
        }

        public String getCartId() {
            return cartId;
        }

        public void setCartId(String cartId) {
            this.cartId = cartId;
        }

        public int getCartStatus() {
            return cartStatus;
        }

        public void setCartStatus(int cartStatus) {
            this.cartStatus = cartStatus;
        }
    }

}
