package com.example.obi1.a3ade;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.util.Log;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Objects;

import static com.example.obi1.a3ade.FirebaseUtil.userName;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, CheckoutFragment.OnFragmentInteractionListener, CartFragment.OnFragmentInteractionListener{
    private RecyclerView mdas_rv;
    public DasRecyclerAdapter dasRecyclerAdapter;
    public static ArrayList<StoreActivity.StoreInfo> firstStoreInfo;  //Holds list of all stores of a particular vendor
    public static ArrayList<StoreActivity.ProductInfo> dashboardFeeds; //Holds sectioned list of all products ever created in all stores in the app
    public static ArrayList<StoreActivity.ProductInfo> storeProducts;  //Holds list of all product in a particular store
    public static ArrayList<StoreActivity.CartListInfo> cartList;    //Holds list of all carts.
    public static ArrayList<StoreActivity.ProductInfo> outgoingCart;
    public static ArrayList<StoreActivity.ProductInfo> incomingCart; //Holds list of all products ever added to cart
    public static ArrayList<StoreActivity.ProductInfo> loadingCart;  //Holds list of all products in a particular cart
    TextView selectedStoreName;
    TextView selectedSDescription;
    public static int navItemId;
    private FrameLayout mstoreInfoDisplay;
    private MenuItem mcheckedMenuItem;
    public static StoreActivity.ProductInfo newProductTemplate;
    private StoreActivity.StoreInfo mselectedStoreInfoFromIntent;
    public static FragmentManager mFragmentManager;
    //public static Fragment mSelectedFragment;

    @Override
    protected void onPause() {
        super.onPause();
        FirebaseUtil.detachAuthListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        FirebaseUtil.openFbReference("tradeData",Dashboard.this);

        // Recycler view reference
        mdas_rv = findViewById(R.id.dashboard_rv);
        final GridLayoutManager dasLayoutManager = new GridLayoutManager(this,2); //Grid Layout reference
        //final LinearLayoutManager dasLayoutManager = new LinearLayoutManager(this); //Grid Layout reference
        mdas_rv.setLayoutManager(dasLayoutManager); //Connects RV and a layout manager

        Intent selectedNavMenuIntent = getIntent();   //Intent from store activity to revive Store or products list Rv after creating new store.
        navItemId = selectedNavMenuIntent.getIntExtra("Selected navMenu", 0);

        mstoreInfoDisplay = (FrameLayout)findViewById(R.id.storeinfo_fl); //Frame layout refernce for store name display

        Intent selectedstore = getIntent();  //Intent from store Activity to Open a store
        mselectedStoreInfoFromIntent = (StoreActivity.StoreInfo) selectedstore.getSerializableExtra("Selected store"); //Selected store from StoreActivity

        updateAdapter(); //Creates recycler adaprter instance and associates with RV.

        if(mselectedStoreInfoFromIntent != null){//Used to populate the store name and description TExtviews
            mstoreInfoDisplay.setVisibility(View.VISIBLE);
            selectedStoreName.setText(mselectedStoreInfoFromIntent.getStoreName());
            selectedSDescription.setText(mselectedStoreInfoFromIntent.getStoreDescription());
        }
        dasRecyclerAdapter.notifyDataSetChanged();
        FirebaseUtil.attachAuthListener();
    }
/*
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FirebaseUtil.RC_SIGN_IN && resultCode == RESULT_OK){ //Handles Login message
            Toast.makeText(Dashboard.this, "Welcome back!!!", Toast.LENGTH_LONG).show();
        }
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        drawer.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {
                TextView userName = (TextView)findViewById(R.id.navhearder_UN_tv);
                userName.setText(FirebaseUtil.userName);  //Used to set username on the navView hearder
            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        if(mcheckedMenuItem == null){
            navigationView.setCheckedItem(R.id.dashboard);
            mcheckedMenuItem = navigationView.getCheckedItem();
        }

        selectedStoreName = (TextView)findViewById(R.id.storename_tv);
        selectedSDescription = (TextView)findViewById(R.id.storedes_tv);

        //Used to remove the storeinfo name and description at startup
        //mstoreInfoDisplay = (FrameLayout)findViewById(R.id.storeinfo_fl);
        //mstoreInfoDisplay.setVisibility(View.GONE);

        if(dashboardFeeds == null){  //Artificial products
            dashboardFeeds = new ArrayList<StoreActivity.ProductInfo>();
            dashboardFeeds.add(new StoreActivity.ProductInfo("Shopify","Earings", "Fascinating", "2", R.mipmap.ic_product_1_foreground, "2000", userName));
            dashboardFeeds.add(new StoreActivity.ProductInfo("Rock 90","Owl Earings","Intriguing", "5", R.mipmap.ic_product_2_foreground,"5000", "Mike White")); //New Feed
            dashboardFeeds.add(new StoreActivity.ProductInfo("A","Huawei y9", "Flexible","9", R.mipmap.ic_product_3_foreground,"150", "Sandra")); //New Feed
            dashboardFeeds.add(new StoreActivity.ProductInfo("B","Oppo N8", "Cool","3", R.drawable.ic_favorite_checked,"1000000", userName)); //New Feed
      /*      dashboardFeeds.add(new StoreActivity.ProductInfo("C","iPhone 8", "128gb","7", R.drawable.ic_menu_slideshow,"N", "Peter")); //New Feed
            dashboardFeeds.add(new StoreActivity.ProductInfo("D","Galaxy s7", "Nice!","2", R.drawable.ic_menu_camera,"N", userName)); //New Feed
            dashboardFeeds.add(new StoreActivity.ProductInfo("E","Huawei y7", "Flexible","4", R.drawable.ic_menu_share,"N", "Yusuf")); //New Feed
            dashboardFeeds.add(new StoreActivity.ProductInfo("F","Oppo N4", "Cool","1", R.drawable.ic_menu_gallery,"N", userName)); */ //New Feed
            }

        newProductTemplate = new StoreActivity.ProductInfo("Non","New Product", "New P","0", R.drawable.ic_das_add_black_24dp," ", userName);
        if(storeProducts == null) { //Products
            storeProducts = new ArrayList<StoreActivity.ProductInfo>();
            storeProducts.add(newProductTemplate); //New product element
        }

        if (firstStoreInfo == null){ //Stores
            firstStoreInfo = new ArrayList<StoreActivity.StoreInfo>();
            firstStoreInfo.add(new StoreActivity.StoreInfo("New Store", "New S", R.drawable.ic_das_add_black_24dp)); //New store element
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        mcheckedMenuItem = item;
        int id = navItemId = item.getItemId();

        if (id == R.id.profile) {
            // Handle the camera action
        } else if (id == R.id.stores) {
            updateAdapter();
        } else if (id == R.id.asserts) {

        } else if (id == R.id.dashboard) {
            updateFrame(navItemId);
            updateAdapter();
        } else if (id == R.id.favorites) {
            Intent intent = new Intent(Dashboard.this, CartActivity.class);
            startActivity(intent);
        } else if (id == R.id.cart) {
            updateFrame(navItemId); //Prepares the Cart Frame Layout for display;

            Fragment selectedFragment = CartFragment.newInstance("My", "Checkout");
            mFragmentManager = getSupportFragmentManager();
            FragmentTransaction fragTransaction = mFragmentManager.beginTransaction();
            fragTransaction.add(R.id.forfragment_fl, selectedFragment);
            //fragTransaction.addToBackStack("CartFragment");
            fragTransaction.commit();

            //updateAdapter();

        } else if (id == R.id.logout) {
            Toast.makeText(Dashboard.this, "Goodbye!", Toast.LENGTH_LONG).show();
            FirebaseUtil.signOut();
            Log.d("Logout", "User Logged Out");
            //FirebaseUtil.attachAuthListener(); //
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        updateAdapter();
        return true;
    }

    public static void prepareInOutCart() {  //shorten this method by removing cartList array from type cartListInfo
        if(incomingCart == null || incomingCart.size() == 0){
            incomingCart = new ArrayList<StoreActivity.ProductInfo>();
            incomingCart.add(new StoreActivity.ProductInfo("Non","Empty",
                    "Fascinating", "2", 0, "0", userName));
        }
        String inEmptyName = incomingCart.get(0).getProductName();
        if(incomingCart.size() >= 2 && inEmptyName == "Empty"){
            incomingCart.remove(0);
        }

        if(outgoingCart == null || outgoingCart.size() == 0){
            outgoingCart = new ArrayList<StoreActivity.ProductInfo>();
            outgoingCart.add(new StoreActivity.ProductInfo("Non","Empty",
                    "Fascinating", "2", 0, "0", userName));
        }
        String outEmptyName = incomingCart.get(0).getProductName();
        if(incomingCart.size() >= 2 && outEmptyName == "Empty"){
            incomingCart.remove(0);
        }

        if(cartList == null || cartList.size() == 0){
            cartList = new ArrayList<StoreActivity.CartListInfo>();
            cartList.add(new StoreActivity.CartListInfo("Empty_0",8));
        }
        String cartEmptyName = cartList.get(0).getCartId();
        if(cartList.size() >= 2 && cartEmptyName == "Empty_0"){
            cartList.remove(0);
        }

        if(loadingCart == null || loadingCart.size() == 0){
            loadingCart = new ArrayList<StoreActivity.ProductInfo>();
            loadingCart.add(new StoreActivity.ProductInfo("Non","Empty",
                    "Fascinating", "2", 0, "0", userName));
        }
        String loadCartEmptyName = loadingCart.get(0).getProductName();
        if(loadingCart.size() >= 2 && loadCartEmptyName == "Empty"){
            loadingCart.remove(0);
        }
    }

    private void updateFrame(int navItemId) {
        FrameLayout mainFrameLayout = (FrameLayout)findViewById(R.id.dasp_fl);
        FrameLayout fragFrameLayout = (FrameLayout)findViewById(R.id.forfragment_fl);
        if(navItemId == R.id.cart){
            mainFrameLayout.setVisibility(View.GONE);
            fragFrameLayout.setVisibility(View.VISIBLE);
        } else{
            mainFrameLayout.setVisibility(View.VISIBLE);
            fragFrameLayout.setVisibility(View.GONE);
        }
    }

    private void updateAdapter() {
        mstoreInfoDisplay.setVisibility(View.GONE);
        //dasrv was formally here.

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        if(navItemId == 300){
            navigationView.setCheckedItem(R.id.stores);
            storeProducts.clear(); //Gets it ready for below.
            storeProducts = porpulateListWithProducts(mselectedStoreInfoFromIntent.getStoreName(), dashboardFeeds);//Populate storeProducts array ahead of time with products from a particular store
        } else navigationView.setCheckedItem(navItemId);

        dasRecyclerAdapter = new DasRecyclerAdapter(this,navItemId);
        mdas_rv.setAdapter(dasRecyclerAdapter);  //Dreated a new adapter to handle The store list data items
        dasRecyclerAdapter.notifyDataSetChanged();

        String Item = mcheckedMenuItem.toString(); //Used to display the navigation title on the tools bars
        mcheckedMenuItem = navigationView.getCheckedItem();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(Item);  //Used to Set the toolbar's title.
    }

    public static ArrayList porpulateListWithProducts(String searchParameter, ArrayList searchLocation) {
        ArrayList shufflingList = new ArrayList(); //Creates the result ArrayLIst
        shufflingList.add(newProductTemplate); //+ New product element
        int range = searchLocation.size();
        int count = 0;
        while(count < range){
            StoreActivity.ProductInfo storeProducts = (StoreActivity.ProductInfo) searchLocation.get(count);
            if(Objects.equals(storeProducts.getStoreName(), searchParameter) || Objects.equals(storeProducts.getCartId(), searchParameter)){
                shufflingList.add(storeProducts);
            }
            count++;
        }
        if(searchLocation == incomingCart){
            shufflingList.remove(0); //Remove newProductTemplate.
        }
        return shufflingList;
    }

    @Override
    public void onFragmentInteraction(Uri uri) {
    }
}
