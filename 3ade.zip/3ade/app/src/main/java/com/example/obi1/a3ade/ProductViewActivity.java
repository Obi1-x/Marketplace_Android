package com.example.obi1.a3ade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

import static com.example.obi1.a3ade.Dashboard.cartList;
import static com.example.obi1.a3ade.Dashboard.incomingCart;
import static com.example.obi1.a3ade.FirebaseUtil.userName;

public class ProductViewActivity extends AppCompatActivity implements Serializable {
    public static int OPENED = 4;
    public static int CLOSED = 8;
    public static int rowClickPos;
    private String mUser;
    private boolean isChecked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_view);
        //Toolbar toolbar;

        ImageView ProductImage = (ImageView) findViewById(R.id.product_image_ib);
        final EditText itemNo = (EditText)findViewById(R.id.item_no_et); //Item number reference
        final ImageButton favoriteButton = (ImageButton)findViewById(R.id.favorite_ib);
        TextView ProductName = (TextView)findViewById(R.id.product_name_tv);
        TextView ProductPrice = (TextView)findViewById(R.id.product_price_tv);
        Button addValidateButton = (Button)findViewById(R.id.add_validate_b);
        final EditText ProductDescription = (EditText)findViewById(R.id.product_descrip_ed);
        //ProductDescription.setText("bldjhsd \n dewewfe   \n ssfefe \n wwrrrfe \n wwrwfrf \n fsfsfssf  \n sfvfvfv \n sfsfvfv \n fdfffwrw" );

        Intent intent = getIntent(); //Receives intent from a product click.
        final StoreActivity.ProductInfo productInfo = (StoreActivity.ProductInfo)intent.getSerializableExtra("Selected product"); //Receives all Extras
        //Gets the user who created the product.
        mUser = productInfo.getUserName();

        ProductImage.setImageResource(productInfo.getProductImage()); //Set product image
        itemNo.setText(productInfo.getProductNo());
        ProductName.setText(productInfo.getProductName()); //Set product name.
        ProductPrice.setText("N" + productInfo.getPrice());//Set product Price.
        ProductDescription.setText(productInfo.getProductDescription());//Set product decription.

        if(mUser.equals(FirebaseUtil.userName)){ //If this is the user that created the product
            favoriteButton.setVisibility(View.GONE);
            addValidateButton.setText(getString(R.string.Validate_button));
        }else{ //If this isnt the user who created the product
            favoriteButton.setVisibility(View.VISIBLE);
            addValidateButton.setText(getString(R.string.Add_to_cart_button));
            itemNo.setEnabled(false);
            ProductDescription.setEnabled(false); //Text colour has to be set in the xml file

            favoriteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(isChecked == true){
                        isChecked = false;
                        favoriteButton.setImageResource(R.drawable.ic_favorite_border_unchecked);
                    } else if(isChecked == false){
                        isChecked = true;
                        favoriteButton.setImageResource(R.drawable.ic_favorite_checked);
                    }
                }
            });
        }

        addValidateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mUser.equals(FirebaseUtil.userName)){
                    productInfo.setProductNo(itemNo.getText().toString());
                    productInfo.setProductDescription(ProductDescription.getText().toString());
                    Dashboard.dashboardFeeds.remove(rowClickPos);
                    Dashboard.dashboardFeeds.add(rowClickPos, productInfo);
                    Intent intent = new Intent(ProductViewActivity.this, Dashboard.class);
                    startActivity(intent);
                    Toast.makeText(ProductViewActivity.this, "Product details updated!", Toast.LENGTH_LONG).show();
                } else{
                    productInfo.setCartId(getIdOfOpenedCart()); //Associats product with cart, through cartId

                    if(incomingCart == null){
                        incomingCart = new ArrayList<StoreActivity.ProductInfo>();
                    }
                    productInfo.setProductNo("1"); //Sets number of products to 1 first, so it can be set later in user's cart
                    incomingCart.add(productInfo);
                    Toast.makeText(ProductViewActivity.this, "Product has been added to IncomingCart", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ProductViewActivity.this, Dashboard.class);
                    startActivity(intent);
                }
            }
        });
    }

    private String getIdOfOpenedCart() {
        String openedCartId = null;
        int cartTally = 0;
        int count = 0;
        int range = cartList.size();

        while (count < range){
            StoreActivity.CartListInfo scaningCart = cartList.get(count);
            if(scaningCart.getCartStatus() == OPENED){ //Look for an open cart
                openedCartId = scaningCart.getCartId();
            }
            count++;
        }
        if(openedCartId == null){  //If non opened, create new cart and give it an id.
            String sample = cartList.get(cartList.size()-1).getCartId();  //Gets the cart_id of the last cart
            cartTally = (int)sample.charAt(sample.length()-1);  //Gets the last carts Tally. -49 is a byte conversion of char to string
            cartTally = cartTally - 47; //- 48 + 1;
            openedCartId = userName.toLowerCase() + "_" + cartTally;  //Concartenate username, _ and cart Tally
            cartList.add(new StoreActivity.CartListInfo(openedCartId, OPENED));
        }
        return openedCartId;
    }
}
