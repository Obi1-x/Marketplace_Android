package com.example.obi1.a3ade;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import static com.example.obi1.a3ade.ProductViewActivity.CLOSED;
import static com.example.obi1.a3ade.ProductViewActivity.OPENED;

public class DasRecyclerAdapter extends RecyclerView.Adapter <DasRecyclerAdapter.DasViewHolder> {
    private static final int PRODUCT_NAV_MENU = 300;
    public static final int OUTGOING_CART_ID = 500;
    public static final int INCOMING_CART_CHECKOUT = 700;
    private final Context viewHolderContext;
    private final LayoutInflater dasLayoutInflater;
    private static ArrayList SPInfo;
    //private static ArrayList<StoreActivity.StoreInfo> SInfo; // Variable for data source
    //private static ArrayList<StoreActivity.ProductInfo> PInfo;
    public static int navMenuId;
    public static int rowclickPosition;
    public static int cost, check;

    public DasRecyclerAdapter(Context viewHolderContext, int navMenuId) {
        this.viewHolderContext = viewHolderContext;  //An Inflater needs a context to function
        this.navMenuId = navMenuId;  //.getTitle();
        dasLayoutInflater = LayoutInflater.from(this.viewHolderContext); //Create an inflater with the context above
        switch (navMenuId){
            case R.id.stores:
                this.SPInfo = Dashboard.firstStoreInfo; //Get store data
                break;
            case R.id.dashboard:
                this.SPInfo = Dashboard.dashboardFeeds; //Get product data
                break;
            case R.id.cart:
                this.SPInfo = Dashboard.cartList;  //Get List of cart data.
                break;
            case INCOMING_CART_CHECKOUT:
                this.SPInfo = Dashboard.loadingCart;  //Get a particular cart's data.
                check = 0;
                cost = getCost();
                break;
            case OUTGOING_CART_ID:
                //this.SPInfo = Dashboard.outgoingCart;
                this.SPInfo = Dashboard.cartList;
                cost = 0;
                break;
            case PRODUCT_NAV_MENU:
                this.SPInfo = Dashboard.storeProducts; //Get product data
                break;
            default:
                this.SPInfo = Dashboard.dashboardFeeds; //Get product data.
                break;
        }
        Dashboard.prepareInOutCart();
    }

    private static int getCost() {
        int counting = 0;
        int dynamicPrice = 0;
        while(counting < SPInfo.size()){
            StoreActivity.ProductInfo product = (StoreActivity.ProductInfo) SPInfo.get(counting);
            int price = Integer.parseInt(product.getPrice());
            int stock = Integer.parseInt(product.getProductNo());  //Value is gotten from incoming cart array instead
            dynamicPrice = dynamicPrice + price * stock;
            counting++;
        }
        return dynamicPrice;
    }

    //public DasRecyclerAdapter(ArrayList<StoreActivity.StoreInfo> storelist){}

    @NonNull
    @Override
    public DasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //View dasItemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.das_row_rv, parent, false);
        View dasItemView = dasLayoutInflater.inflate(R.layout.das_row_rv, parent, false); // Inflate the view using the a layout resource and the created inflater.
        return new DasViewHolder(dasItemView); //New instance of DasViewHolder parsing in the inflated View.
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull DasViewHolder holder, int position) {
        if(navMenuId == R.id.stores){ //Binds store data
            StoreActivity.StoreInfo store = (StoreActivity.StoreInfo) SPInfo.get(position);
            holder.storeName.setText(store.getStoreName());
            holder.storeImage.setImageResource(store.getImage());
            holder.productPrice.setVisibility(View.GONE);
            holder.favorites.setVisibility(View.GONE);
            holder.storeImage.setImageResource(R.drawable.ic_store_icon);
            //  holder.rowPosition = position;

        } else if(navMenuId == R.id.cart || navMenuId == OUTGOING_CART_ID){
            StoreActivity.CartListInfo cartList = (StoreActivity.CartListInfo)SPInfo.get(position);
            if(cartList.getCartId() == "Empty_0"){
               holder.storeName.setText("Empty");
            }
             else holder.storeName.setText(cartList.getCartId());

            if(cartList.getCartStatus() == OPENED || holder.storeName.getText() == "Empty"){
                holder.productPrice.setText("....");
                holder.productPrice.setTextColor(R.color.darkTextColor);
            } else holder.productPrice.setText("PAID");

            holder.storeImage.setImageResource(R.drawable.ic_cart);
            holder.favorites.setVisibility(View.GONE);

        } else{  //Binds product data
            StoreActivity.ProductInfo product = (StoreActivity.ProductInfo) SPInfo.get(position);
            holder.storeName.setText(product.getProductName());
            holder.storeImage.setImageResource(product.getProductImage());

            if(navMenuId == INCOMING_CART_CHECKOUT){
                if(check <= SPInfo.size()){ //Initially populating the RV
                    holder.stockSelect.setSelection(Integer.parseInt(product.getProductNo())-1);
                }
                int price = Integer.parseInt(product.getPrice());
                int stock = Integer.parseInt(holder.stockSelect.getSelectedItem().toString());  //Value is gotten from the spinner instead
                int dynamicPrice = price * stock;
                holder.productPrice.setText("N" + dynamicPrice); //Sets price * the number of items selected with the spinner.

                Button checkout = (Button)CheckoutFragment.mWorkingView.findViewById(R.id.checkout_b);
                checkout.setText("CHECKOUT N"+ DasRecyclerAdapter.cost);  //This should be done only once in cart fragment
                Log.d("Button Set", String.valueOf(cost));

            } else holder.productPrice.setText("N" + product.getPrice()); //Sets Price per item straight from Cart array
        }
    }

    @Override
    public int getItemCount() {
        return SPInfo.size(); // Size of data from source
    }
/*
    @Override
    public void onViewRecycled(@NonNull DasViewHolder holder) {
        super.onViewRecycled(holder);
        Log.d("Recycling", "Recycled");
    }*/

    public static class DasViewHolder extends RecyclerView.ViewHolder {
        TextView storeName;
        public TextView productPrice;
        ImageView storeImage;
        public static ImageButton favorites;
        public static  ImageButton deleteCartProduct;
        Spinner stockSelect;

        public DasViewHolder(@NonNull final View itemView) { //Constructor matching super Should describe how to bind data to  single row
            super(itemView);
            storeName = (TextView)itemView.findViewById(R.id.storename_das_tv);
            productPrice = (TextView)itemView.findViewById(R.id.product_price_tv);
            storeImage = (ImageView)itemView.findViewById(R.id.storeimage_das_iv);
            favorites = (ImageButton)itemView.findViewById(R.id.rv_favorite_ib);
            deleteCartProduct = (ImageButton)itemView.findViewById(R.id.remove_from_cart_ib);
            deleteCartProduct.setVisibility(View.INVISIBLE);

            if(navMenuId == INCOMING_CART_CHECKOUT){ //If view holder is created for cart.
               String numbers[] = {"1", "2", "3", "4"};

                deleteCartProduct.setVisibility(View.VISIBLE);  //Add the delete icon only when in incoming cart
                StoreActivity.CartListInfo cart = Dashboard.cartList.get(rowclickPosition);
                stockSelect = new Spinner(itemView.getContext());
                ArrayAdapter cartFlow = new ArrayAdapter(itemView.getContext(), android.R.layout.simple_spinner_item, numbers); //Array Adapter to serve spinner data.
                cartFlow.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); //Dropdown Spinner resource reference
                stockSelect.setAdapter(cartFlow);
                ConstraintLayout dasRowCl = (ConstraintLayout)itemView.findViewById(R.id.das_row_cl); // Row CL reference
                stockSelect.setLayoutParams(favorites.getLayoutParams()); // Transfer Favorite Imgae button parameters to that spinner.
                dasRowCl.removeView(favorites); //Replace favorite image button
                dasRowCl.addView(stockSelect);      //With spinner

                if(cart.getCartStatus() == OPENED){
                    stockSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) { //Once the spinner item  has been set
                            check++;
                            Log.d("I selected","Selected!!!");
                            if(check > SPInfo.size()){ //This condition was put there to avoid refreshing the Rv Adapter after the initial item setting of eack row spinner.
                                StoreActivity.ProductInfo product = (StoreActivity.ProductInfo) SPInfo.get(getAdapterPosition());
                                product.setProductNo(adapterView.getSelectedItem().toString()); //Set the product no according to the spinner selection
                                CheckoutFragment.mCartRecyclerAdapter.notifyDataSetChanged();
                                Log.d("I have refreshed","Refreshed!!!");
                            }
                            cost = DasRecyclerAdapter.getCost();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });

                    deleteCartProduct.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            int productPosition = getAdapterPosition();  //Get the position of the item to be deleted
                            SPInfo.remove(productPosition); //Delete it
                            check = SPInfo.size()-1; //Makes variable "check" 1 less than the Array size, in other to address the issue of resetting the spinners after an item gets deleted
                            Dashboard.prepareInOutCart(); //Call the cleanup method I created to avoid a null pointer error
                            cost = getCost(); //recalculate the total cost.
                            CheckoutFragment.mCartRecyclerAdapter.notifyDataSetChanged(); // Refresh Rv adapter
                        }
                    });
                } else if(cart.getCartStatus() == CLOSED){
                    deleteCartProduct.setImageResource(R.drawable.ic_processing);
                    stockSelect.setEnabled(false);
                }
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    rowclickPosition = getAdapterPosition(); //Get the RV row position were the click occurred

                    if(navMenuId == R.id.dashboard || navMenuId == R.id.stores || navMenuId == PRODUCT_NAV_MENU || navMenuId == 0){
                    if (rowclickPosition == 0) {
                        //Toast.makeText(itemView.getContext(), "Creating New store!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(itemView.getContext(), StoreActivity.class);
                        itemView.getContext().startActivity(intent);
                    } else {
                        if (DasRecyclerAdapter.navMenuId == R.id.stores) {
                            //   Toast.makeText(itemView.getContext(), "Opening store!", Toast.LENGTH_LONG).show();
                            StoreActivity.StoreInfo store = (StoreActivity.StoreInfo) SPInfo.get(rowclickPosition); //Select store from ArrayList
                            Intent intent = new Intent(itemView.getContext(), Dashboard.class);
                            intent.putExtra("Selected store", store);
                            intent.putExtra("Selected navMenu", PRODUCT_NAV_MENU); //A virtual nav Menu was created for Store Products.
                            StoreActivity.rowClickPos = rowclickPosition;
                            itemView.getContext().startActivity(intent);
                        } else {
                            //   Toast.makeText(itemView.getContext(), "Opening Product!", Toast.LENGTH_LONG).show();
                            StoreActivity.ProductInfo product = (StoreActivity.ProductInfo) SPInfo.get(rowclickPosition); //Select store from ArrayList
                            Intent intent = new Intent(itemView.getContext(), ProductViewActivity.class);
                            intent.putExtra("Selected product", product);
                            ProductViewActivity.rowClickPos = rowclickPosition;
                            //intent.putExtra("Selected navMenu", PRODUCT_NAV_MENU); //A virtual nav Menu was created for Store Products.
                            itemView.getContext().startActivity(intent);
                        }
                    }
                }

                if(navMenuId == R.id.cart){
                    Fragment fraging = CheckoutFragment.newInstance("My", "Checkout");
                    FragmentTransaction transaction = Dashboard.mFragmentManager.beginTransaction();
                    transaction.replace(R.id.forfragment_fl, fraging);
                    transaction.addToBackStack("Checkout");
                    transaction.commit();
                    //((CheckoutFragment) fraging).onButtonPressed();
                }
                }
            });
        }
    }

}
