package com.example.obi1.a3ade;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;

public class FirebaseUtil {
    public static FirebaseDatabase myFirebase;
    public static DatabaseReference mydatabase;
    private static FirebaseUtil firebaseUtil; //Reference to firebase
    public static FirebaseAuth myFirebaseAuth; //FB authentication variable
    public static FirebaseAuth.AuthStateListener myAuthListener; //FB authentication listener variable
    public static final int RC_SIGN_IN = 123;
    private static Activity caller; // Caller activity variable
    public static String userName;
    private FirebaseUtil(){}//Private constructor to avoid this class from getting instantiated

    public static void openFbReference(String ref, final Activity activity) {
        if (firebaseUtil == null){
            firebaseUtil = new FirebaseUtil(); //New firebase util instance
            //Create Firebase db refernce.
            myFirebase = FirebaseDatabase.getInstance(); //Instance of Firebase DB
            //mydatabase = myFirebase.getReference("message");
            myFirebaseAuth = FirebaseAuth.getInstance(); //FB auth object initialization
            caller = activity; //Starts the login activity

            myAuthListener = new FirebaseAuth.AuthStateListener() {  //FB auth LIstener object.
                @Override
                public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                    if (firebaseAuth.getCurrentUser() == null) { //This checks if the current user is not signed in
                        signIn(); //Signin if not

                        Log.d("LogIn", "User Logging In");
                    } else {
                        String userId = firebaseAuth.getUid(); //Retrieves the user id of the current user
                        //checkAdmin(userId); //Checks if the user is an admin with the acquired id
                        FirebaseUser username = firebaseAuth.getCurrentUser();
                        userName = username.getDisplayName(); //Used to get username.
                        //StoreActivity.StoreInfo dashingboard = Dashboard.dashboardFeeds.get(1);
                        //dashingboard.setUserName(userName);
                    }
                }
            };
        }

        //mDeals = new ArrayList<TravelDealNG>(); //New Empty array
        mydatabase = myFirebase.getReference().child(ref); //Opens the path that was passed in as an argument (parameter)
    }

    public static void signOut() {
        AuthUI.getInstance()
                .signOut(caller)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    public void onComplete(@NonNull Task<Void> task) {
                        // ...
                    }
                });
    }


    // DatabaseReference myRef = mydatabase.getReference().child(ref);
   // myRef.setValue("Hello, World!");

    private static void signIn() { //Sign in method You can change back to static
        // Choose authentication providers
        List<AuthUI.IdpConfig> providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build(),
                new AuthUI.IdpConfig.GoogleBuilder().build());

// Create and launch sign-in intent
        caller.startActivityForResult(
                AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setAvailableProviders(providers)
                        .setIsSmartLockEnabled(false)
                        //  .setLogo(R.drawable.travel_mantics_icon_64dp)      // Set logo drawable
                        .setTheme(R.style.AppTheme)      // Set theme
                        .build(),
                RC_SIGN_IN);

    }



    public static void detachAuthListener() {
        myFirebaseAuth.removeAuthStateListener(myAuthListener);//detach auth statelistener when not needed.
    }

    public static void attachAuthListener() {
        myFirebaseAuth.addAuthStateListener(myAuthListener); //Attach auth statelistener when needed.
    }
}
